//
//  TabView.swift
//  projetofinal
//
//  Created by Turma02-6 on 13/11/25.
//

import SwiftUI

struct Principal: View {
    var body: some View {
        TabView {
            TelaInicialView()
                .tabItem{Label("", systemImage: "house")}
            ContentView()
                .tabItem{Label("", systemImage: "arrow.up.arrow.down")}
            

        }
    }
}

#Preview {
    Principal()
}
