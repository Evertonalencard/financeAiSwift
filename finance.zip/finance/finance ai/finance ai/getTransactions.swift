//
//  api-rest-request.swift
//  api_rest_harry-potter
//
//  Created by Turma02 on 29/10/25.
//

import Foundation

struct Category: Codable, Hashable {
    let name: String
}

struct Transaction: Codable, Hashable {
    let _id:String
    let _rev: String
    let descricao: String
    let valor: Double
    let data: Int
    let category:Category
}

class ViewModel: ObservableObject {
    @Published var transactions: [Transaction] = []
    
    func fetch() {
        guard let url = URL(string: "http://127.0.0.1:1880/getTransactions") else {
            print("Erro ao criar URL")
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
                
            guard let data = data, error == nil else {
                return
            }
            
            do {
                
                let parsed = try JSONDecoder().decode([Transaction].self, from: data)
            
                DispatchQueue.main.async {
                    self?.transactions = parsed
                }
                
            } catch {
                print(error)
            }
            
        }
        
        task.resume()
        
    }
    
}
