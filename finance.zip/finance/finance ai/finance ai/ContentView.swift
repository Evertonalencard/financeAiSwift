//
//  ContentView.swift
//  finance ai
//
//  Created by Turma02 on 10/11/25.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var viewModel = ViewModel()
    
    var body: some View {
        
        let sortedTransactions = viewModel.transactions.sorted {
            $0.data > $1.data
        }
        
        ZStack {
            Color.esmerald
                .ignoresSafeArea()
            VStack {
                Text("Finance AI")
                    .font(.system(size: 30, weight: .bold, design: .default))
                    .foregroundStyle(.creme)
                
                ForEach(sortedTransactions, id: \.self) {
                    transaction in
                    Text(transaction.descricao)
                }
                
            }
        }.onAppear() {
            viewModel.fetch()
        }
    }
    
}

#Preview {
    ContentView()
}
