//
//  gemini_apiApp.swift
//  gemini-api
//
//  Created by Turma02 on 04/11/25.
//

import SwiftUI

@main
struct gemini_apiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
