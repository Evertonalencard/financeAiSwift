//
//  gemini_apiTests.swift
//  gemini-apiTests
//
//  Created by Turma02 on 04/11/25.
//

import Testing
@testable import gemini_api

struct gemini_apiTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
